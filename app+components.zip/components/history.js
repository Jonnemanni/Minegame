import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View, Button, Alert, TextInput, FlatList } from 'react-native';

export default function History({ route, navigation }) {

  const { list } = route.params;

  return (
    <View style={styles.container}>
        <View>
            <FlatList style={styles.list}
                data={list}
                renderItem={({ item }) => <Text>{item.key}</Text>}
                keyExtractor={(item, index) => index.toString()}
            />
        </View>   
        <StatusBar hidden={true} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  }
});
