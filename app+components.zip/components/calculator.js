import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View, Button, Alert, TextInput, FlatList } from 'react-native';

export default function Calculator({ navigation }) {

  const [value1, setValue1] = React.useState();
  const [value2, setValue2] = React.useState();
  const [outcome, setOutcome] = React.useState();
  const [list, setList] = React.useState([]);

  const loglist = () => {
    console.log(list);
  }

  const addvalues = () => {
    if (isNaN(value1) || isNaN(value2)){
      setOutcome("Error: One of the values is Not a Number.")
    } else {
    let result = parseFloat(value1)+parseFloat(value2);
    setOutcome(result)

    let item = value1 + " + " + value2 + " = " + result;

    setList([...list, { key: item }]);
    }
  }

  const subtractvalues = () => {
    if (isNaN(value1) || isNaN(value2)){
      setOutcome("Error: One of the values is Not a Number.")
    } else {
    let result = parseFloat(value1)-parseFloat(value2);
    setOutcome(result)

    let item = value1 + " - " + value2 + " = " + result;

    setList([...list, { key: item }]);
    }
  }

  const multiplyvalues = () => {
    if (isNaN(value1) || isNaN(value2)){
      setOutcome("Error: One of the values is Not a Number.")
    } else {
    let result = parseFloat(value1)*parseFloat(value2);
    setOutcome(result)

    let item = value1 + " * " + value2 + " = " + result;

    setList([...list, { key: item }]);
    }
  }

  const dividevalues = () => {
    if (isNaN(value1) || isNaN(value2)){
      setOutcome("Error: One of the values is Not a Number.")
    } else {
    let result = parseFloat(value1)/parseFloat(value2);
    setOutcome(result)

    let item = value1 + " / " + value2 + " = " + result;

    setList([...list, { key: item }]);
    }
  }

  return (
    <View style={styles.container}>
      <Text>Outcome: {outcome}</Text>
      <Text>Value 1:</Text>
      <TextInput
        style={{width:200, borderColor:'grey', borderWidth:1}}
        onChangeText={value1 => setValue1(value1)}
        value={value1}
        keyboardType="numeric"
      />
      <Text>{"\n"}</Text>
      <Text>Value 2:</Text>
      <TextInput
        style={{width:200, borderColor:'grey', borderWidth:1}}
        onChangeText={value2 => setValue2(value2)}
        value={value2}
        keyboardType="numeric"
      />
      
      <Text>{"\n"}</Text>

      <View style={{ flexDirection:"row" }}>
        
        <View style={{width:28}}>
          <Button
            onPress = {addvalues}
            title="+"
          />
        </View>

        <Text>      </Text>

        <View style={{width:28}}>
          <Button
            onPress = {subtractvalues}
            title="-"
          />
        </View>

      <Text>      </Text>
      
        <View style={{width:28}}>
          <Button
            onPress = {multiplyvalues}
            title="*"
          />
        </View>

        <Text>      </Text>
        
        <View style={{width:28}}>
          <Button
            onPress = {dividevalues}
            title="÷"
          />
        </View>

      </View>

      <Button title="Settings" onPress={() => navigation.navigate('History', {list: list})}/>

      <StatusBar hidden={true} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  }
});
